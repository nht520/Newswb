<template>
    <div id="Carousels">
      <v-carousel
        delimiter-icon="stop"
        prev-icon="mdi-arrow-left"
        next-icon="mdi-arrow-right"
      >
        <v-carousel-item
          v-for="(item,i) in carousels"
          :key="i"
          :src="item.src"
        ></v-carousel-item>
      </v-carousel>
    </div>
</template>

<script>
    export default {
        name: "Carousels",
         props:{
           carousels:{}
         },
        data(){
          return{
            // items: [
            //   {
            //     src: 'https://cdn.vuetifyjs.com/images/carousel/squirrel.jpg'
            //   },
            //   {
            //     src: 'https://cdn.vuetifyjs.com/images/carousel/sky.jpg'
            //   },
            //   {
            //     src: 'https://cdn.vuetifyjs.com/images/carousel/bird.jpg'
            //   },
            //   {
            //     src: 'https://cdn.vuetifyjs.com/images/carousel/planet.jpg'
            //   }
            // ]
          }
        }
    }
</script>

<style scoped>

</style>
